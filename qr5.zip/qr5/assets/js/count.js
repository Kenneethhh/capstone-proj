

$(document).ready(function(){
  

   
   function load_count(load = '')
   {
      $.ajax({
         url:"../partial/fetch-req-count.php",
         method:"POST",
         data:{load:load},
         dataType:"json",
         success:function(data)
         {
         $('#count_req').html(data.count_req);
         $('#total_count').html(data.total_req);


        

        
         }
      });
   }
 
   load_count();
 
   
 
  


 
   setInterval(function(){ 
      load_count();
   }, 5000);
 
});
