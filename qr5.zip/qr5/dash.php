<?php session_start() ?>
<?php
include 'includes/db_conn.php';


$query = 'SELECT COUNT(*) FROM users WHERE registered_as = "Student"';
$result = mysqli_query($connection, $query);
$row = mysqli_fetch_array($result);
$total = $row[0];

// registered_as Teacher

$query = 'SELECT COUNT(*) FROM users WHERE registered_as = "Teacher"';
$result = mysqli_query($connection, $query);
$row = mysqli_fetch_array($result);
$total2 = $row[0];







?>






<!DOCTYPE html>
<html lang="zxx">
   <head>
      <!-- The above 6 meta tags *must* come first in the head; any other head content must come *after* these tags -->
      <meta charset="utf-8">
      <meta http-equiv="x-ua-compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="description" content="">
      <meta name="keyword" content="">
      <meta name="author"  content=""/>
      <!-- Page Title -->
      <title>PAUSC-TIS v1.0 | Dashboard</title>
      <!-- Main CSS -->			
      <link type="text/css" rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css"/>
      <link type="text/css" rel="stylesheet" href="assets/plugins/font-awesome/css/font-awesome.min.css"/>
      <link type="text/css" rel="stylesheet" href="assets/plugins/flag-icon/flag-icon.min.css"/>
      <link type="text/css" rel="stylesheet" href="assets/plugins/simple-line-icons/css/simple-line-icons.css">
      <link type="text/css" rel="stylesheet" href="assets/plugins/ionicons/css/ionicons.css">
      <link type="text/css" rel="stylesheet" href="assets/plugins/toastr/toastr.min.css">
      <link type="text/css" rel="stylesheet" href="assets/plugins/apex-chart/apexcharts.css">
      <link type="text/css" rel="stylesheet" href="assets/css/app.min.css"/>
      <link type="text/css" rel="stylesheet" href="assets/css/style.min.css"/>
      <link rel="stylesheet" href="assets/plugins/fullcalendar/fullcalendar.min.css">
    <link rel="stylesheet" href="assets/plugins/fullcalendar/fullcalendar.print.css" media="print">
      
      
      <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
      <!-- WARNING: Respond.js doesn"t work if you view the page via file:// -->
      <!--[if lt IE 9]>
      <script src="http://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
   </head>
   <body>
    <div class="page-inner">
    <!-- Main Wrapper -->
    <?php include 'includes/navbar.php' ?>
    <div id="main-wrapper">
       <!--================================-->
       <!-- Breadcrumb Start -->
       <!--================================-->
       <div class="pageheader pd-t-25 pd-b-35">
          <div class="pd-t-5 pd-b-5">
             <h1 class="pd-0 mg-0 tx-20">PHINMA AU-South Campus Tap Identification System</h1>
          </div>
          <div class="breadcrumb pd-0 mg-0">
             <a class="breadcrumb-item" href="index.php"><i class="icon ion-ios-home-outline"></i> Home</a>
             <a class="breadcrumb-item" href="">Dashboard</a>
           
          </div>
       </div>
       <!--/ Breadcrumb End -->
       <div class="row row-xs clearfix">
          <!--================================-->
          <!-- Count Start -->
          <!--================================-->	
          <div class="col-sm-6 col-xl-3">
             <div class="card mg-b-20">
                <div class="card-body">
                   <div class="media d-inline-flex">
                      <div>
                         <span class="tx-uppercase tx-10 mg-b-10">STUDENTS ENROLLED</span>					  
                         <h2 class="tx-20 tx-sm-18 tx-md-24 mb-0 mt-2 mt-sm-0 tx-normal tx-rubik tx-dark"><span class="counter"><?php echo $total ?></span></h2>
                          <span class="float-left small tx-gray-500"><br></span> 
                      </div>
                   </div>
                   
                   <div class="progress ht-3 op-5">
                      <div class="progress-bar bg-primary wd-100p" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                   </div>
                </div>
             </div>
          </div>
          <div class="col-sm-6 col-xl-3">
             <div class="card mg-b-20">
                <div class="card-body">
                   <div class="media d-inline-flex">
                      <div>
                         <span class="tx-uppercase tx-10 mg-b-10">TEACHERS</span>					  
                         <h2 class="tx-20 tx-sm-18 tx-md-24 mb-0 mt-2 mt-sm-0 tx-normal tx-rubik tx-dark"><span class="counter"><?php echo $total2 ?></span> </h2>
                      </div>
                   </div>
                   <div class="clearfix"> 
                      <span class="float-left small tx-gray-500">---</span> 
                      
                      <span class="float-right">
                        <span class="tx-dark">---</span><span class="small mg-b-0">---</span>
                     
                      </span>
                   </div>
                   <div class="progress ht-3 op-5">
                      <div class="progress-bar bg-warning wd-90p" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                   </div>
                </div>
             </div>
          </div>
          <div class="row">
       <div class="col-md-6 col-lg-6">
             <div class="card mg-b-20">
                <div class="card-header">
                   <h4 class="card-header-title">
                      Calendar
                   </h4>

                   <div class="card-header-btn">
                    
                   </div>
                   
                </div>

                <div class="card-body pd-0 collapse show" id="collapse7">

                    <div class="col-md-12">
<div class="panel panel-default">
<div class="panel-heading"> <i class="glyphicon glyphicon-calendar"></i></div>
<div class="panel-body">
 <div id="calendar"></div>
</div>   
</div>

</div><br><br>
                  
                </div>
             </div>
          </div>

         
         
       </div>
       


    </div>



        
    
         
          
       
    <!--/ Main Wrapper End -->
 </div>
 <!--/ Page Inner End -->
 <!--================================-->
 <!-- Page Footer Start -->	

 <!--/ Page Footer End -->		
</div>
<!--/ Page Content End -->
</div>
<!--/ Page Container End -->
<!--================================-->
<!-- Scroll To Top Start-->
<!--================================-->	
<a href="" data-click="scroll-top" class="btn-scroll-top fade" style="background-color: rgb(5,80,154); color: white" ><i class="fa fa-arrow-up"></i></a>
<!--/ Scroll To Top End -->
<!--================================-->


<!--=========add anouncement========-->
      <div class="modal" id="m_modal_4" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel_4" aria-hidden="true">
                      <div class="modal-dialog modal-lg" role="document">
                         <div class="modal-content">
                            <div class="modal-header">
                               <h5 class="modal-title" id="exampleModalLabel_4">Announcement</h5>
                               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                               <span aria-hidden="true"><i class="ion-ios-close-empty"></i></span>
                               </button>
                            </div>
                            <div class="modal-body">
                               <form>
                                  <div class="form-group">
                                     <input type="text" name="" class="form-control" placeholder="Announcement Header" style="width: 50%">
                                  </div>
                                    <div class="form-group">
                                    <textarea class="form-control" rows="15" placeholder="content"></textarea>
                                  </div>
                                   <div class="col-md-6 mg-b-30">
                         <hr class="d-md-none">
                      
                         <div class="input-group form-type-fill file-group">
                            <input type="text" class="form-control file-value" placeholder="Choose file..." readonly="">
                            <input type="file" multiple="">
                            <span class="input-group-btn">
                            <button class="btn btn-custom-primary file-browser" type="button"><i class="fa fa-upload"></i></button>
                            </span>
                         </div>
                      </div>

                                 
                                 
                              
                            </div>
                            <div class="modal-footer">
                               <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                               <button type="button" class="btn btn-primary">Post</button>
                            </div>
                         </form>
                         </div>
                      </div>
                   </div>

<!--/ Setting Sidebar End  -->      
<!--================================-->

<!--/ Demo Sidebar End  -->
<!--================================-->
<!-- Footer Script -->
<!--================================-->
<script src="assets/plugins/jquery/jquery.min.js"></script>
<script src="assets/plugins/jquery-ui/jquery-ui.js"></script>
<script src="assets/plugins/popper/popper.js"></script>
<script src="assets/plugins/feather-icon/feather.min.js"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/plugins/pace/pace.min.js"></script>
<script src="assets/plugins/toastr/toastr.min.js"></script>
<script src="assets/plugins/countup/counterup.min.js"></script>		
<script src="assets/plugins/waypoints/waypoints.min.js"></script>
<script src="assets/plugins/apex-chart/apexcharts.min.js"></script>
<script src="assets/plugins/apex-chart/irregular-data-series.js"></script>
<script src="assets/plugins/google-chart/google-chart.min.js"></script>
<script src="assets/plugins/simpler-sidebar/jquery.simpler-sidebar.min.js"></script>
<script src="assets/js/dashboard/education-dashboard-init.js"></script>
<script src="assets/js/jquery.slimscroll.min.js"></script>
<script src="assets/js/highlight.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/custom.js"></script>
<script src="assets/plugins/moment/moment.min.js"></script>
<script src="assets/plugins/fullcalendar/fullcalendar.min.js"></script>
<script
src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js">
</script>


<script type="text/javascript">
$(document).ready(function(){

 $('#calendar').fullCalendar();



});
</script>

<script type="text/javascript">

var xValues = ["Jan", "Feb", "Mrch"];
var yValues = [7050, 4500, 15000];

new Chart("myChart1", {
type: "line",

data: {
labels: xValues,
datasets: [{

borderColor: "rgba(5,80,154,0.7)",
data: yValues
}]
},
// options:{...}
});

//alert('test');
const labels = ["BRAND-A", "BRAND-B", "BRAND-C"];
const data = {
labels: labels,
datasets: [{
label: 'BRAND AND CATEGORY',
data: [65, 59, 80],
backgroundColor: [
'rgba(255, 99, 132, 0.2)',
'rgba(255, 159, 64, 0.2)',
'rgba(255, 205, 86, 0.2)',
'rgba(75, 192, 192, 0.2)',
'rgba(54, 162, 235, 0.2)',
'rgba(153, 102, 255, 0.2)',
'rgba(201, 203, 207, 0.2)'
],
borderColor: [
'rgb(255, 99, 132)',
'rgb(255, 159, 64)',
'rgb(255, 205, 86)',
'rgb(75, 192, 192)',
'rgb(54, 162, 235)',
'rgb(153, 102, 255)',
'rgb(201, 203, 207)'
],
borderWidth: 1
}]
};

const config = {
type: 'bar',
data: data,
options: {
scales: {
y: {
beginAtZero: true
}
}
},
};

new Chart("myChart2", config);
</script>



</body>
</html>

 
