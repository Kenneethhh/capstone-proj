<?php

$sql = "SELECT * FROM attendance LEFT JOIN users ON attendance.student_id = users.user_id WHERE users.registered_as = 'Student' ";

$filters = [];

if (isset($_POST['f_year']) && $_POST['f_year'] != null) {
    $filters[] = 'users.year = "' . $_POST['f_year'] . '"';
}

if (isset($_POST['f_course']) && $_POST['f_course'] != null) {
    $filters[] = 'users.course = "' . $_POST['f_course'] . '"';
}

if (isset($_POST['f_section']) && $_POST['f_section'] != null) {
    $filters[] = 'users.section = "' . $_POST['f_section'] . '"';
}

if (isset($_POST['f_id']) && $_POST['f_id'] != null) {
    $filters[] = 'attendance.student_id = "' . $_POST['f_id'] . '"';
}

if (isset($_POST['f_date']) && $_POST['f_date'] != null) {
    $filters[] = 'attendance.date = "' . $_POST['f_date'] . '"';
}

if (count($filters)) {
    $sql .= ' AND ' .  implode(' AND ', $filters);
}

//  echo $sql;



 $sql .= " group by student_id,date order by date DESC";
$sqlResult = mysqli_query($connection, $sql);

?>




<form action="view_attendance.php" method="post">
    <center>
        <input type="text" placeholder="Year" name="f_year" style="width:19%;" value="<?php if (isset($_POST['f_year'])) {
                                                                                            echo  $_POST['f_year'];
                                                                                        } ?>">
        <input type="text" placeholder="Course" name="f_course" style="width:19%;" value="<?php if (isset($_POST['f_course'])) {
                                                                                                echo  $_POST['f_course'];
                                                                                            } ?>">
        <input type="text" placeholder="Section" name="f_section" style="width:19%;" value="<?php if (isset($_POST['f_section'])) {
                                                                                                echo  $_POST['f_section'];
                                                                                            } ?>">
        <input type="text" placeholder="ID" name="f_id" style="width:19%;" value="<?php if (isset($_POST['f_id'])) {
                                                                                        echo  $_POST['f_id'];
                                                                                    } ?>">
        <input type="date" placeholder="Date" name="f_date" style="width:19%;" value="<?php if (isset($_POST['f_date'])) {
                                                                                            echo  $_POST['f_date'];
                                                                                        } ?>">
        <br><br>
        <input type="submit" value="Filter">
        <br>
    </center>
</form>



<div class="table mt">
    <br>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No.</th>
                <th>Student ID</th>
                <th>Student Name</th>
                <th>Year</th>
                <th>Course</th>
                <th>Date</th>
                <th>Time IN</th>
                <th>Time OUT</th>
            </tr>
        </thead>

        <?php

        if ($sqlResult) {
            if (mysqli_num_rows($sqlResult) == '0') {
                echo '<h1>No Result found</h1>';
            }
            $sno = 0;
            while ($attendance_row = mysqli_fetch_assoc($sqlResult)) {
                $student_id = $attendance_row['student_id'];
                $student_name = $attendance_row['first_name'] . ' ' . $attendance_row['last_name'];
                $year = $attendance_row['year'];
                $course = $attendance_row['course'];
                $date = $attendance_row['date'];
                $time = $attendance_row['time'];
                $log = $attendance_row['log'];
                $sno++;
         
                $logs_sql = "SELECT student_id,date,max(time) as time_out, min(time) as time_in FROM `attendance` where student_id='".$student_id."' and date='".$date."' ";
                $log_result = mysqli_query($connection, $logs_sql);
                while ($log_row = mysqli_fetch_assoc($log_result)) {
                    $time_in =   date("h:i A",strtotime($log_row["time_in"]));

                    if($log_row["time_out"] == $log_row["time_in"]){
                        $time_out = "-";
                    }else{
                        $time_out = date("h:i A",strtotime($log_row["time_out"]));
                    }

                  
                    
                    ?>
                    <tr>
                        <td><?php echo $sno ?></td>
                        <td><?php echo $student_id ?></td>
                        <td><?php echo $student_name ?></td>
                        <td><?php echo $year ?></td>
                        <td><?php echo $course ?></td>
                        <td><?php echo $date ?></td>
                        <td><?php echo $time_in; ?></td>
                        <td><?php echo $time_out ?></td>
    
                    </tr>
            <?php


                    
                }




    
            }
        }

        ?>


        <tbody>








        </tbody>
    </table>
</div>

</div>
</div>
</div>
</header>
<?php include 'includes/footer.php' ?>
</body>

</html>