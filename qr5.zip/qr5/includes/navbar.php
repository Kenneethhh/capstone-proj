<?php
if (isset($_SESSION['loggedin'])) {
  $status = $_SESSION['logged_as'];
  $role = "(" . ($status) . ")";
} else {
  $role = "";
}
?>

<nav style="background-color:#007bff;" class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
  <div class="container">
    <a class="navbar-brand js-scroll-trigger" href="index.php">
      <img src="./includes/pau.png" alt="logo" height="auto" width="auto" style="max-height:50px; max-width:100%; margin-right:10px;">
      PAUSC-TIS v1.0 <?php echo $role; ?>
    </a>

    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav ml-auto my-2 my-lg-0">
        <?php
        if (isset($_SESSION['loggedin'])) {
          // echo '
          //   <li class="nav-item">
          //   <a class="nav-link js-scroll-trigger" href="index.php">Message</a>
          // </li>';
          if ($_SESSION['logged_as'] == 'Student' || $_SESSION['logged_as'] == 'Teacher') {
            echo '
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="view_Myinfo.php">My Information</a>
            </li>

            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="view_qr.php">QR Code</a>
            </li>
            ';
          } else {
            echo '
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="dash2.php">Dashboard</a>
            </li>
            
            ';

            echo '
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="scan_qr.php">SCAN QR CODE</a>
            </li>
            
            ';
          }


          if ($_SESSION['logged_as'] == 'Student') {
            echo '
       

            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Attendance
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="view_attendance.php?type=student&as=campus">Campus Attendance</a>
              <a class="dropdown-item" href="view_attendance.php?type=student&as=class">Class Attendance</a>
            
            </div>
          </li>
            ';
          } else {
            echo '
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="view_attendance.php">Attendance</a>
            </li>
            
            ';
          }

          if ($_SESSION['logged_as'] == 'Admin') {
            echo '
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="user_list.php">User list</a>
            </li>
            

            
            ';
          }
          //   <li class="nav-item">
          //   <a class="nav-link js-scroll-trigger" href="report.php">Report</a>
          // </li>


          echo '
          
          
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="includes/logout.php">Logout</a>
          </li>
            ';
        } else {
          echo '
            <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="login.php">Sign in</a>
          </li>
          <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="verify_email.php" target="_blank">Sign up</a>
          </li>';
        }
        //   <li class="nav-item">
        //     <a class="nav-link js-scroll-trigger" href="signup.php">Register</a>
        //   </li>
        //         ';
        // } 
        ?>

      </ul>
    </div>
  </div>
</nav>

<br>