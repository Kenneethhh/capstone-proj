<?php
session_start();
include 'db_conn.php';
if (isset($_POST['submit'])) {
    $student_id = $_POST['id'];
    $student_name = $_POST['name'];
    $date = $_POST['date'];
    if ($_SESSION['logged_as'] == 'Teacher') {
        $time = $_POST['time'];
        $query = "";
        $sql = "SELECT * FROM attendance WHERE student_id = '$student_id'";

        $result = mysqli_query($connection, $sql);

        $nrows = mysqli_num_rows($result);

        if (($nrows % 2) == 0) {
            $query = "INSERT INTO `attendance` (`student_id`, `name`, `date`, `time`, `status`, `log`)
     VALUES ('$student_id', '$student_name', '$date','$time', 'Present', 'IN')";
        } else {
            $query = "INSERT INTO `attendance` (`student_id`, `name`, `date`, `time`, `status`, `log`)
     VALUES ('$student_id', '$student_name', '$date','$time', 'Present', 'OUT')";
        }

        $result = mysqli_query($connection, $query);
        if ($result) {
            echo '<script>alert("Attendance Successfully Submitted")</script>';
            echo '<script>
            window.location.href = "../index.php"
            </script>';
        } else {
            echo '<script>alert("Attendance did not Submitted. Please try again")</script>';
            echo '<script>
            window.location.href = "../index.php"
            </script>';
        }
    }
}
