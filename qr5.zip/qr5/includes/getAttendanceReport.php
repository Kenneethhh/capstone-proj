<?php 

require_once 'db_conn.php';

if($_POST) {
	// get start date
	$startDate = $_POST['startDate'];
	// get end date
	$endDate = $_POST['endDate'];

	$sql = "SELECT * FROM attendance WHERE date BETWEEN '$startDate' AND '$endDate' ORDER BY date ASC";
	
	







}
