<?php
$server_name = "localhost";
$username = "root";
$pass = "";
$db_name = "qr_system";

$connection = mysqli_connect($server_name, $username, $pass, $db_name);
