<?php

// $used_subj = "";
// session_start();
// +++++++++++++++++++++++++++++++++++++++++++++++ SELECT TEACHER SUBJECTS ++++++++++++++++++++++++++++++
$t_id = $_SESSION['user_id'];
$sql_subjects = "SELECT subject FROM `user_subject` WHERE user_id = '$t_id'";
$result_subj = mysqli_query($connection, $sql_subjects);
if ($result_subj && mysqli_num_rows($result_subj) > 0) {
    $subjects = array();
    while ($row = mysqli_fetch_assoc($result_subj)) {
        $subjects[] = $row['subject'];
    }
}

$sub_sql = "SELECT * from user_subject where user_id='" . $t_id . "' order by subject";
$subResult = mysqli_query($connection, $sub_sql);

$sub_sql_ini = "SELECT * from user_subject where user_id='" . $t_id . "' order by subject limit 1";
$subResult_ini = mysqli_query($connection, $sub_sql_ini);

$from = date("Y-m-d");




// ++++++++++++++++++++++++++++++++++++++++++++++++++ SELECT STUDENTS CURRENTLY INSIDE THE CAMPUS ++++++++++++++++++++++

// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++ FILTERED++++++++++++++++
if (isset($_POST['filter'])) {
    $subject = $_POST['subject_filter'];
    $from = $_POST["start_date"];
} else {
    while ($subj_ini = mysqli_fetch_assoc($subResult_ini)) {
        $subject = $subj_ini["subject"];
    }
}

$sql = "SELECT users.first_name, users.last_name, users.section, attendance_subject.user_id, attendance_subject.date, attendance_subject.teacher_id 
        FROM user_subject 
        INNER JOIN users ON user_subject.user_id = users.user_id 
        LEFT JOIN attendance_subject ON user_subject.user_id = attendance_subject.user_id AND attendance_subject.subject = user_subject.subject AND attendance_subject.date = '$from'
        WHERE user_subject.subject = '$subject' AND users.registered_as = 'STUDENT'
        ORDER BY  users.section ASC, users.last_name ASC, users.first_name ASC ";
$sqlResult = mysqli_query($connection, $sql);

// create a new sql query, select all users that is registered_as Student and has a subject equal to $subject?

$stud_sql = "SELECT us.* FROM user_subject us
             INNER JOIN attendance_subject ats ON us.user_id = ats.user_id
             WHERE us.subject = '$subject' AND us.user_id LIKE '01-%'
             AND ats.subject = '$subject' AND ats.date = '$from'";

$student_enrolled_query = mysqli_query($connection, $stud_sql);
$student_count_present = mysqli_num_rows($student_enrolled_query);

$stud_sql = "SELECT * FROM user_subject WHERE subject = '$subject' AND user_id LIKE '01-%'";
$student_enrolled_query = mysqli_query($connection, $stud_sql);
$student_count = mysqli_num_rows($student_enrolled_query);

?>



<form action="view_attendance.php" method="post">
    <div class="row">
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-6">
                    <h2> Filter Subject</h2>
                    <select class="form-control form-select" name="subject_filter" id="subject_filter">

                        <?php
                        while ($subj = mysqli_fetch_assoc($subResult)) {
                            if ($subject == $subj["subject"]) {
                                echo '<option value="' . $subj["subject"] . '" selected>' . $subj["subject"] . '</option>';
                            } else {
                                echo '<option value="' . $subj["subject"] . '">' . $subj["subject"] . '</option>';
                            }
                        }


                        ?>
                    </select>
                </div>


            </div>

            <div class="row">
                <div class="col-md-6 mt-2">

                    <input class="form-control form-date" type="date" id="start_date" name="start_date" value="<?php echo $from; ?>">
                </div>
            </div>



            <div class="row">
                <div class="col-md-6 mt-2">

                    <input type="submit" value="Filter" id="filter" name='filter' class="btn btn-success btn-lg">

                </div>
            </div>

        </div>

        <div class="col-md-6">

            <div class="card mg-b-20">
                <div class="card-body">
                    <div class="media d-inline-flex">
                        <div>
                            <span class="tx-uppercase tx-10 mg-b-10"> <?php echo $subject; ?></span>
                            <h2 class="tx-20 tx-sm-18 tx-md-24 mb-0 mt-2 mt-sm-0 tx-normal tx-rubik tx-dark"><span class="counter"><?php echo $student_count_present . " out of " .  $student_count ?> </span></h2> Students Attended
                            <span class="float-left small tx-gray-500"><br></span>
                        </div>
                    </div>

                    <div class="progress ht-3 op-5">
                        <div class="progress-bar bg-primary wd-100p" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>

        </div>


    </div>










</form>
<br>

<!-- Add a container for the dropdown button -->
<div class="dropdown" style="float: right;">
    <button class="btn btn-success btn-lg m-1 dropdown-toggle" type="button" data-toggle="dropdown">
        Export Table
    </button>
    <div class="dropdown-menu">
        <a class="dropdown-item" onclick="downloadTable('example', 'pdf')" style="cursor: pointer;">Export to PDF</a>
        <a class="dropdown-item" onclick="downloadTable('example', 'sls')" style="cursor: pointer;">Export to XLSX</a>
    </div>
</div>

<div class="font-weight-bold mb-2">Show:</div>

<div class="form-inline mb-3">
    <div class="form-check mr-2">
        <input class="form-check-input" type="checkbox" id="presentCheckbox" name="presentCheckbox" checked>
        <label class="form-check-label" for="presentCheckbox">Present</label>
    </div>
    <div class="form-check mr-2">
        <input class="form-check-input" type="checkbox" id="absentCheckbox" name="absentCheckbox" checked>
        <label class="form-check-label" for="absentCheckbox">Absent</label>
    </div>
</div>






<?php

if ($sqlResult) {
    // Display the table
    echo '<div class="table mt">
        <br>
        <table class="table table-bordered" id="example">
            <thead>
                <tr>
                    <th colspan="4">
                        <h3> Class Attendance for ' . $subject . ' (' . $from . ') </h3>
                    </th>
                </tr>
                <tr>
                    <th>No.</th>
                    <th>Student Name</th>
                    <th>Section</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>';

    // Loop through each row of the result set and display the data in the table
    $sno = 0;
    while ($row = mysqli_fetch_assoc($sqlResult)) {
        $sno++;
        $status = $row['date'] ? "Present" : "Absent";
        $name = $row['last_name'] . " " .  $row['first_name'];
        $section = $row['section'];
        echo '<tr name="showtd">
            <td>' . $sno . '</td>
            <td>' . $name . '</td>
            <td>' . $section . '</td>
            <td name="tdline">' . $status . '</td>
        </tr>';
    }

    // Close the table
    echo '</tbody></table></div>';
} else {
    // If the query fails, display an error message
    echo "Error: " . mysqli_error($connection);
}

?>

</div>
</div>
</div>
</header>
<?php include 'includes/footer.php' ?>
</body>


<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
<script src="https://unpkg.com/xlsx/dist/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
<script type="text/javascript">
    function toggleTdByContentAndParent(td_name, status, turn_on) {
        var elements = document.querySelectorAll('td[name="' + td_name + '"]');

        for (var i = 0; i < elements.length; i++) {
            var element = elements[i];
            if (element.innerText.trim() === status) {
                var parent = element.parentNode;
                if (turn_on) {
                    parent.style.display = "none";
                } else {
                    parent.style.display = "";
                }
            }
        }
    }



    function listenCheckbox(id, stat) {
        var checkbox = document.getElementById(id);
        checkbox.addEventListener('change', function() {
            if (checkbox.checked) {

                toggleTdByContentAndParent('tdline', stat, false);

            } else {
                toggleTdByContentAndParent('tdline', stat, true);

            }
        });
    }

    listenCheckbox('presentCheckbox', 'Present');
    listenCheckbox('absentCheckbox', 'Absent');
</script>


<!-- <script type="text/javascript">
    $("body").on("click", "#export_to_pdf", function() {
        html2canvas($('#example')[0], {
            onrendered: function(canvas) {
                var data = canvas.toDataURL();
                var docDefinition = {
                    content: [{
                        image: data,
                        width: 500
                    }]
                };
                pdfMake.createPdf(docDefinition).download("attendance_class.pdf");

            }
        });
    });
</script> -->

<script type="text/javascript">
    function downloadTable(id, type) {
        // Get the table element
        const table = document.getElementById(id);

        if (type === 'sls') {
            // Convert table to spreadsheet
            const wb = XLSX.utils.table_to_book(table);
            // Generate and download the file
            XLSX.writeFile(wb, 'table.xlsx');
        } else if (type === 'pdf') {
            // Convert table to PDF
            html2pdf()
                .from(table)
                .save('table.pdf');
        } else {
            console.error('Invalid type: ' + type);
        }
    }
</script>

</html>