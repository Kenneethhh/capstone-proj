<?php

// $used_subj = "";
// session_start();
// +++++++++++++++++++++++++++++++++++++++++++++++ SELECT TEACHER SUBJECTS ++++++++++++++++++++++++++++++
$t_id = $_SESSION['user_id'];


$sql_subjects = "SELECT subject FROM `user_subject` WHERE user_id = '$t_id'";
$result_subj = mysqli_query($connection, $sql_subjects);
if ($result_subj && mysqli_num_rows($result_subj) > 0) {
    $subjects = array();
    while ($row = mysqli_fetch_assoc($result_subj)) {
        $subjects[] = $row['subject'];
    }
}

$sub_sql = "SELECT * from user_subject where user_id='" . $t_id . "' order by subject";
$subResult = mysqli_query($connection, $sub_sql);

$sub_sql_ini = "SELECT * from user_subject where user_id='" . $t_id . "' order by subject limit 1";
$subResult_ini = mysqli_query($connection, $sub_sql_ini);

$from = date("Y-m-d");
$to = date("Y-m-d");



$stud_sql = "SELECT * from user_subject where user_id like '01-%' ";
$student_enrolled_query = mysqli_query($connection, $stud_sql);
$student_count = mysqli_num_rows($student_enrolled_query);
// ++++++++++++++++++++++++++++++++++++++++++++++++++ SELECT STUDENTS CURRENTLY INSIDE THE CAMPUS ++++++++++++++++++++++

// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++ FILTERED++++++++++++++++
if (isset($_POST['filter'])) {
    $subject = $_POST['subject_filter'];
    $from = $_POST["start_date"];
    $to = $_POST["end_date"];
} else {
    while ($subj_ini = mysqli_fetch_assoc($subResult_ini)) {
        $subject = $subj_ini["subject"];
    }
}

$sql = "SELECT users.first_name, users.last_name, users.section, 
COUNT(CASE WHEN attendance_subject.subject = '$subject' THEN attendance_subject.id END) AS count
FROM users 
INNER JOIN user_subject ON users.user_id = user_subject.user_id 
LEFT JOIN attendance_subject ON users.user_id = attendance_subject.user_id
    AND attendance_subject.date BETWEEN '$from' AND '$to' 
    AND attendance_subject.subject = '$subject'
WHERE user_subject.subject = '$subject' 
AND users.registered_as = 'Student'
GROUP BY users.user_id
ORDER BY users.section ASC, users.last_name ASC, users.first_name ASC;
";
$sqlResult = mysqli_query($connection, $sql);

// create a new sql query, select all users that is registered_as Student and has a subject equal to $subject?

?>



<form action="view_attendance.php" method="post">
    <div class="row">
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-6">
                    <h2> Filter Subject</h2>
                    <select class="form-control form-select" name="subject_filter" id="subject_filter">

                        <?php
                        while ($subj = mysqli_fetch_assoc($subResult)) {
                            if ($subject == $subj["subject"]) {
                                echo '<option value="' . $subj["subject"] . '" selected>' . $subj["subject"] . '</option>';
                            } else {
                                echo '<option value="' . $subj["subject"] . '">' . $subj["subject"] . '</option>';
                            }
                        }


                        ?>
                    </select>
                </div>


            </div>

            <div class="row">
                <div class="col-md-6 mt-2">
                    <label for="start_date">From: </label>
                    <input class="form-control form-date" type="date" id="start_date" name="start_date" value="<?php echo $from; ?>">
                    <label for="end_date">To: </label>
                    <input class="form-control form-date" type="date" id="end_date" name="end_date" value="<?php echo $to; ?>">
                </div>
            </div>



            <div class="row">
                <div class="col-md-6 mt-2">

                    <input type="submit" value="Filter" id="filter" name='filter' class="btn btn-success btn-lg">

                </div>
            </div>

        </div>




    </div>










</form>

<!-- Add a container for the dropdown button -->
<div class="dropdown" style="float: right;">
    <button class="btn btn-success btn-lg m-1 dropdown-toggle" type="button" data-toggle="dropdown">
        Export Table
    </button>
    <div class="dropdown-menu">
        <a class="dropdown-item" onclick="downloadTable('example', 'pdf')" style="cursor: pointer;">Export to PDF</a>
        <a class="dropdown-item" onclick="downloadTable('example', 'sls')" style="cursor: pointer;">Export to XLSX</a>
    </div>
</div>





<?php

if ($sqlResult) {
    // Display the table
    echo '<div class="table mt">
        <br>
        <table class="table table-bordered" id="example">
            <thead>
                <tr>
                    <th colspan="4">
                        <h3> Class Attendance for ' . $subject . ' (' . $from . ') - (' . $to . ')</h3>
                    </th>
                </tr>
                <tr>
                    <th>No.</th>
                    <th>Student Name</th>
                    <th>Section</th>
                    <th>Total Attendance</th>
                </tr>
            </thead>
            <tbody>';

    // Loop through each row of the result set and display the data in the table
    $sno = 0;
    while ($row = mysqli_fetch_assoc($sqlResult)) {
        $sno++;
        $name = $row['last_name'] . " " .  $row['first_name'];
        $section = $row['section'];
        $count = $row['count'];
        echo '<tr>
            <td>' . $sno . '</td>
            <td>' . $name . '</td>
            <td>' . $section . '</td>
            <td>' . $count . '</td>
        </tr>';
    }

    // Close the table
    echo '</tbody></table></div>';
} else {
    // If the query fails, display an error message
    echo "Error: " . mysqli_error($connection);
}

?>

</div>
</div>
</div>
<br><br><br>
</header>
<?php include 'includes/footer.php' ?>
</body>


<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
<script src="https://unpkg.com/xlsx/dist/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>


<!-- <script type="text/javascript">
    $("body").on("click", "#export_to_pdf", function() {
        html2canvas($('#example')[0], {
            onrendered: function(canvas) {
                var data = canvas.toDataURL();
                var docDefinition = {
                    content: [{
                        image: data,
                        width: 500
                    }]
                };
                pdfMake.createPdf(docDefinition).download("attendance_class.pdf");

            }
        });
    });
</script> -->

<script type="text/javascript">
    function downloadTable(id, type) {
        // Get the table element
        const table = document.getElementById(id);

        if (type === 'sls') {
            // Convert table to spreadsheet
            const wb = XLSX.utils.table_to_book(table);
            // Generate and download the file
            XLSX.writeFile(wb, 'table.xlsx');
        } else if (type === 'pdf') {
            // Convert table to PDF
            html2pdf()
                .from(table)
                .save('table.pdf');
        } else {
            console.error('Invalid type: ' + type);
        }
    }
</script>

</html>