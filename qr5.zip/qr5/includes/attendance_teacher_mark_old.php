<?php
// $used_subj = "";
// session_start();
// +++++++++++++++++++++++++++++++++++++++++++++++ SELECT TEACHER SUBJECTS ++++++++++++++++++++++++++++++
$t_id = $_SESSION['user_id'];
$sql_subjects = "SELECT subject FROM `user_subject` WHERE user_id = '$t_id'";
$result_subj = mysqli_query($connection, $sql_subjects);
if ($result_subj && mysqli_num_rows($result_subj) > 0) {
    $subjects = array();
    while ($row = mysqli_fetch_assoc($result_subj)) {
        $subjects[] = $row['subject'];
    }
}


// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++  MARK ATTENDANCE +++++++++++++++++++++++++++++++


if (isset($_POST['submit'])) {
    $teacher_id = $_SESSION['user_id'];
    $nf_subj = $_SESSION['subject_filter'];
    $currentDate = date("Y,m,d");

    if (isset($_POST['mark'])) {
        foreach ($_POST['mark'] as $student_id => $value) {
            // echo $student_id . '<br>';
            $sql_mark = "INSERT INTO `attendance_subject`(`user_id`, `subject`, `date`, `teacher_id`) VALUES ('$student_id','$nf_subj','$currentDate','$teacher_id')";
            mysqli_query($connection, $sql_mark);
        }
    }
    // echo $_SESSION['subject_filter'] . "fsdfsdf";
}



// ++++++++++++++++++++++++++++++++++++++++++++++++++ SELECT STUDENTS CURRENTLY INSIDE THE CAMPUS ++++++++++++++++++++++

// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++ FILTERED++++++++++++++++
if (isset($_POST['filter'])) {
    $f_subj = "";
    $f_date = "";

    if (isset($_POST['f_subject']) && $_POST['f_subject'] != null) {
        $f_subj = $_POST['f_subject'];
        $used_subj = $f_subj;
    }
    $_SESSION['subject_filter'] = $f_subj;
    $nf_subj = $f_subj;


    $f_date = date("Y,m,d");


    $sql = "SELECT users.user_id, users.first_name, users.last_name, users.section 
    FROM users 
    INNER JOIN user_subject ON users.user_id = user_subject.user_id 
    INNER JOIN attendance ON users.user_id = attendance.student_id 
    WHERE user_subject.subject = '$f_subj' 
    AND attendance.date = '$f_date' 
    AND NOT EXISTS (
      SELECT 1 
      FROM attendance_subject 
      WHERE attendance_subject.user_id = users.user_id 
      AND attendance_subject.subject = '$f_subj' 
      AND attendance_subject.date = '$f_date'
    )
    GROUP BY users.user_id 
    HAVING COUNT(*) % 2 != 0
";
    // echo $sql;
    $sqlResult = mysqli_query($connection, $sql);
} else {
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ NO FILTER +++++++++++++++++++++++++++

    if (isset($_SESSION['subject_filter']) && $_SESSION['subject_filter'] != "") {
        $nf_subj = $_SESSION['subject_filter'];
        // echo $nf_subj . "dadadasd";
    } else {
        $nf_subj = $subjects[0];
    }

    $currentDate = date("Y,m,d");
    $sql = "SELECT users.user_id, users.first_name, users.last_name, users.section 
    FROM users 
    INNER JOIN user_subject ON users.user_id = user_subject.user_id 
    INNER JOIN attendance ON users.user_id = attendance.student_id 
    WHERE user_subject.subject = '$nf_subj' 
    AND attendance.date = '$currentDate' 
    AND NOT EXISTS (
      SELECT 1 
      FROM attendance_subject 
      WHERE attendance_subject.user_id = users.user_id 
      AND attendance_subject.subject = '$nf_subj' 
      AND attendance_subject.date = '$currentDate'
    )
    GROUP BY users.user_id 
    HAVING COUNT(*) % 2 != 0
    ";

    // $used_subj = $subjects[0];
    $sqlResult = mysqli_query($connection, $sql);
}

?>


<form action="view_attendance.php" method="post">
    <center>
        <input list="subject-options" id="subjects" placeholder="Subject" name="f_subject" value="<?php echo isset($_POST['f_subject']) ? $_POST['f_subject'] : '' ?>">

        <datalist id="subject-options">
            <?php
            // Loop through the subjects array and add each as a datalist option
            foreach ($subjects as $subject) {
                echo "<option value=\"$subject\">";
            }
            ?>
        </datalist>



        <br><br>
        <!-- <input type="submit" value="Filter" name="filter"> -->
        <button class="btn btn-secondary" type="submit" name="filter" value="Filter">Filter</button>
        <br>
    </center>
</form>



<div class="table mt">
    <br>
    <form action="" method="post">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <td colspan="4">
                        <center><?php echo $nf_subj ?></center>
                    </td>
                </tr>
                <tr>
                    <th>No.</th>
                    <th>Student Name</th>
                    <th>Section</th>
                    <th>Present</th>
                </tr>
            </thead>

            <?php

            if ($sqlResult) {
                if (mysqli_num_rows($sqlResult) == '0') {
                    echo '<h1>No Result found</h1>';
                }
                $sno = 0;
                while ($attendance_row = mysqli_fetch_assoc($sqlResult)) {
                    $student_name = $attendance_row['first_name'] . ' ' . $attendance_row['last_name'];
                    $section = $attendance_row['section'];
                    $student_id = $attendance_row['user_id'];

                    $sno++;

            ?>
                    <tr>
                        <td><?php echo $sno ?></td>
                        <td><?php echo $student_name ?></td>
                        <td><?php echo $section ?></td>
                        <td> <input type="checkbox" name="mark[<?php echo $student_id ?>]" id=""></td>

                    </tr>
            <?php
                }
            }
            ?>
        </table>
        <center>
            <!-- <input type="submit" value="Submit" name="submit"> -->
            <button class="btn btn-primary" type="submit" name="submit" value="Submit">Submit</button>
        </center>
    </form>
</div>

</div>
</div>
</div>
</header>
<?php include 'includes/footer.php' ?>
</body>

</html>