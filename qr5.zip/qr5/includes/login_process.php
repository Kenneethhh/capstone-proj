<?php
session_start();
include 'db_conn.php';

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare statement to prevent SQL injection attacks
    $stmt = mysqli_prepare($connection, "SELECT * FROM users WHERE email=?");
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) == 0) {
        $_SESSION['error'] = "Account does not exist";
        header("Location: ../login.php");
        exit;
    }

    while ($val = mysqli_fetch_assoc($result)) {
        $user_id = $val['user_id'];
        $hash = $val['password'];
        $db_email = $val['email'];
        $first_name = $val['first_name'];
        $last_name = $val['last_name'];
        $phone = $val['phone'];
        $logged_as = $val['registered_as'];

        if (password_verify($password, $hash)) {
            $_SESSION['loggedin'] = true;
            $_SESSION['name'] = $first_name . ' ' . $last_name;
            $_SESSION['user_id'] = $user_id;
            $_SESSION['logged_as'] = $logged_as;
            header("Location: ../index.php");
            exit;
        } else {
            $_SESSION['error'] = "Password is incorrect";
            header("Location: ../login.php");
            exit;
        }
    }
} else {
    header("Location: ../login.php");
    exit;
}
