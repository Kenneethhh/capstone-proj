<?php
$u_id = $_SESSION['user_id'];
$sql = "SELECT * FROM attendance_subject LEFT JOIN users ON attendance_subject.user_id = users.user_id WHERE attendance_subject.user_id = '$u_id'";
$from = date("Y-m-d");
$to = date("Y-m-d");
$sub = "%";
if(isset($_POST['subject_filter'])){
     $from = $_POST['start_date'];
    $to = $_POST['start_to'];
    
    
    $sub = $_POST['subject_filter'];
    if($sub == "all") {$sub = "%";}

    $sql .= " AND subject LIKE '".$sub."' ";

}


$sql .= "AND date BETWEEN '".$from."' AND '".$to."' ";

// echo $sql;
$sql .= " group by attendance_subject.user_id,date order by date DESC";

$sqlResult = mysqli_query($connection, $sql);


$sub_sql = "SELECT * from user_subject where user_id='".$u_id."' ";
$subResult = mysqli_query($connection, $sub_sql);

$total_days = dateDiffInDays($from,$to);

function dateDiffInDays($date1, $date2) 
  {
      // Calculating the difference in timestamps
      $diff = strtotime($date2) - strtotime($date1);
  
      // 1 day = 24 hours
      // 24 * 60 * 60 = 86400 seconds
      return abs(round($diff / 86400)) + 1;
  }

?>




<br>
<form action="view_attendance.php?type=student&as=class" method="post">
    <center>
     

       <div class="row">
        <div class="col-md-6">
        <h2> Filter Subject</h2>
        <select class="form-control form-select" name="subject_filter" id="subject_filter">
            <option value="all">All Subject</option>
        <?php
                while ($subj = mysqli_fetch_assoc($subResult)) {
                        if($sub == $subj["subject"]){
                            echo '<option value="'.$subj["subject"].'" selected>'.$subj["subject"].'</option>';


                        }else{
                            echo '<option value="'.$subj["subject"].'">'.$subj["subject"].'</option>';

                        }


                   

                }


        ?>
        </select>
        </div>
       </div>
     

        <div class="row">
            

                <div class="col-md-6">
           
                <input class="form-control form-date" type="date" id="start_date" name="start_date" value="<?php echo $from; ?>">

                </div>
                <div class="col-md-6">
         
                <input class="form-control" type="date" id="start_to" name="start_to" value="<?php echo $to; ?>">

                </div>
        </div>
       
        

        <div class="row">
            <div class="col-md-12 mt-2">
            
            <input type="submit" value="Filter" class="btn btn-success btn-lg">
            </div>
        </div>

    </center>
</form>


<div class="table mt">

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No.</th>
                <th>Date</th>
                <th>Subject</th>
                <th>Teacher</th>
            </tr>
        </thead>

        <?php

        if ($sqlResult) {
          

            echo '<h2><center>Class Attendance</center></h2>';

            if($sub != "%"){
            ?>
        <center>
        <div class="col-sm-6 col-xl-6 mb-4">
             <div class="card mg-b-20">
                <div class="card-body">
                   <div class="media d-inline-flex">
                      <div>
                         <span class="tx-uppercase tx-10 mg-b-10"> <?php echo $sub; ?></span>					  
                         <h2 class="tx-20 tx-sm-18 tx-md-24 mb-0 mt-2 mt-sm-0 tx-normal tx-rubik tx-dark"><span class="counter"><?php echo mysqli_num_rows($sqlResult) ." of ".  $total_days ?> days</span></h2>
                          <span class="float-left small tx-gray-500"><br></span> 
                      </div>
                   </div>
                   
                   <div class="progress ht-3 op-5">
                      <div class="progress-bar bg-primary wd-100p" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                   </div>
                </div>
             </div>
          </div>
            </center>

            <?php
                }

            $sno = 0;
            while ($attendance_row = mysqli_fetch_assoc($sqlResult)) {
                $date = $attendance_row['date'];
                $subject = $attendance_row['subject'];
                $teacher_id = $attendance_row["teacher_id"];
                
                $sno++;
                $teacher_sql = "SELECT * from users where user_id='".$teacher_id."' limit 1";
                $teacher_result = mysqli_query($connection, $teacher_sql);
                while ($teacher_row = mysqli_fetch_assoc($teacher_result)) {
                  
                    
                    ?>
                    <tr>
                        <td><?php echo $sno ?></td>
                        <td><?php echo $date ?></td>
                        <td><?php echo $subject; ?></td>
                        <td><?php echo $teacher_row["first_name"]." ".$teacher_row["last_name"]; ?></td>
    
                    </tr>
                <?php


                }  
                

            }
        }

        ?>


        <tbody>








        </tbody>
    </table>
</div>

</div>
</div>
</div>
</header>
<?php include 'includes/footer.php' ?>
</body>

</html>