<?php
include('./phpqrcode/qrlib.php');
$filename = $id . '.png';
$filepath = './img/' . $filename;
if (file_exists($filepath)) {
    unlink($filepath);
}
$path = './img/';

QRcode::png($id, $path . '' . $id . '.png');
