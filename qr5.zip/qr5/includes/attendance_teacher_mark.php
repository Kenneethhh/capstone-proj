<?php
// $used_subj = "";
// session_start();
$from = date("Y-m-d");
$sub = "all";
// +++++++++++++++++++++++++++++++++++++++++++++++ SELECT TEACHER SUBJECTS ++++++++++++++++++++++++++++++
$t_id = $_SESSION['user_id'];
$sql_subjects = "SELECT subject FROM `user_subject` WHERE user_id = '$t_id'";
$result_subj = mysqli_query($connection, $sql_subjects);
if ($result_subj && mysqli_num_rows($result_subj) > 0) {
    $subjects = array();
    while ($row = mysqli_fetch_assoc($result_subj)) {
        $subjects[] = $row['subject'];
    }
}


$sub_sql = "SELECT * from user_subject where user_id='" . $t_id . "' order by subject";
$subResult = mysqli_query($connection, $sub_sql);

$sub_sql_ini = "SELECT * from user_subject where user_id='" . $t_id . "' order by subject limit 1";
$subResult_ini = mysqli_query($connection, $sub_sql_ini);


// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++  MARK ATTENDANCE +++++++++++++++++++++++++++++++


if (isset($_POST['marked'])) {
    $teacher_id = $_SESSION['user_id'];


    $nf_subj = $_POST["curr_subject"];
    $currentDate = $_POST["curr_date"];
    $del_sql = "DELETE from attendance_subject where teacher_id='" . $teacher_id . "' and subject='" . $nf_subj . "' and date='" . $currentDate . "' ";
    mysqli_query($connection, $del_sql);
    if (isset($_POST['mark'])) {
        foreach ($_POST['mark'] as $student_id => $value) {;

            // echo $student_id . '<br>';
            $sql_mark = "INSERT INTO `attendance_subject`(`user_id`, `subject`, `date`, `teacher_id`) VALUES ('$student_id','$nf_subj','$currentDate','$teacher_id')";
            mysqli_query($connection, $sql_mark);
        }
    }

    echo '
    <script>alert("Mark Submitted")</script>

    ';

    // echo $_SESSION['subject_filter'] . "fsdfsdf";
}



// ++++++++++++++++++++++++++++++++++++++++++++++++++ SELECT STUDENTS CURRENTLY INSIDE THE CAMPUS ++++++++++++++++++++++

// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++ FILTERED++++++++++++++++
if (isset($_POST['filter'])) {
    $subject = $_POST['subject_filter'];
} else {
    while ($subj_ini = mysqli_fetch_assoc($subResult_ini)) {
        $subject = $subj_ini["subject"];
    }
}



if (isset($_POST['start_date'])) {

    $from = $_POST["start_date"];
}


$sql = "SELECT * from user_subject join users on users.user_id = user_subject.user_id where subject = '" . $subject . "' and registered_as ='STUDENT' ";
$sqlResult = mysqli_query($connection, $sql);



?>




<form action="view_attendance.php" method="post">
    <div class="row">
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-6">
                    <h2> Filter Subject</h2>
                    <select class="form-control form-select" name="subject_filter" id="subject_filter">

                        <?php
                        while ($subj = mysqli_fetch_assoc($subResult)) {
                            if ($subject == $subj["subject"]) {
                                echo '<option value="' . $subj["subject"] . '" selected>' . $subj["subject"] . '</option>';
                            } else {
                                echo '<option value="' . $subj["subject"] . '">' . $subj["subject"] . '</option>';
                            }
                        }


                        ?>
                    </select>
                </div>


            </div>





            <div class="row">
                <div class="col-md-6 mt-2">

                    <input type="submit" value="Filter" id="filter" name='filter' class="btn btn-success btn-lg">
                </div>
            </div>

        </div>


    </div>










</form>



<div class="table mt">
    <form action="view_attendance.php" method="post">

        <div class="row">

            <div class="col-md-2"> Attendance For:</div>
            <div class="col-md-3 mb-2">

                <input class="form-control form-date" type="date" id="start_date" name="start_date" value="<?php echo $from; ?>">

            </div>

            <div class="col-md-3 mb-2">
                <button class="btn btn-success btn-sm" type="submit" name="date_for" id="date_for">Change Date </button>


            </div>

        </div>


    </form>


    <form action="view_attendance.php" method="post">
        <input type="hidden" value="<?php echo $subject; ?>" name="curr_subject">
        <input type="hidden" value="<?php echo $from; ?>" name="curr_date">



        <table class="table table-bordered">

            <thead>
                <tr>
                    <div>
                        <ul style="list-style:none; display:flex; justify-content:flex-end;">
                            <li style="margin-right: 10px; font-weight: bold;"><span style="display:inline-block; width:10px; height:10px; border-radius:50%; background-color:green; margin-right:5px;"></span>INSIDE</li>
                            <li style="margin-right: 10px; font-weight: bold;"><span style="display:inline-block; width:10px; height:10px; border-radius:50%; background-color:yellow; margin-right:5px;"></span>OUTSIDE</li>
                            <li style="font-weight: bold;"><span style="display:inline-block; width:10px; height:10px; border-radius:50%; background-color:gray; margin-right:5px;"></span>ABSENT</li>
                        </ul>
                    </div>
                </tr>

                <tr>
                    <th>No.</th>
                    <th>Student Name</th>
                    <th>Section</th>
                    <th>Present</th>
                </tr>
            </thead>

            <?php

            if ($sqlResult) {

                $sno = 0;
                while ($attendance_row = mysqli_fetch_assoc($sqlResult)) {
                    $student_name = $attendance_row['first_name'] . ' ' . $attendance_row['last_name'];
                    $section = $attendance_row['section'];
                    $student_id = $attendance_row['user_id'];

                    $sno++;

                    $sql_att = "SELECT * from attendance where student_id = '" . $student_id . "' and date = '" . $from . "' order by entry_id desc limit 1";
                    $query_att = mysqli_query($connection, $sql_att);
                    if (mysqli_num_rows($query_att) > 0) {
                        $row_att = mysqli_fetch_assoc($query_att);
                        if ($row_att['log'] == 'IN') {
                            $present = 1;
                            $color = "#B4EAA8";
                            $chk_bx = "";
                        } else {
                            $present = 2;
                            $color = "#FAEDAB";
                            $chk_bx = "";
                        }
                    } else {
                        $present = 0;
                        $color = "#C1C0BC";
                        $chk_bx = "disabled";
                    }


                    $sql_att_chk = "SELECT * from attendance_subject where subject='" . $subject . "' and user_id = '" . $student_id . "' and date='" . $from . "' and teacher_id='" . $t_id . "' ";
                    $query_att_chk = mysqli_query($connection, $sql_att_chk);
                    if (mysqli_num_rows($query_att_chk) > 0) {
                        $check_now = "checked";
                    } else {
                        $check_now = "";
                    }


            ?>
                    <tr style="background-color:<?php echo $color; ?>;">
                        <td><?php echo $sno ?></td>
                        <td><?php echo strtoupper($student_name) ?></td>
                        <td><?php echo strtoupper($section) ?></td>
                        <td> <input class="form-control" type="checkbox" name="mark[<?php echo $student_id ?>]" id="" <?php echo $check_now . " " . $chk_bx; ?>>

                        </td>

                    </tr>
            <?php
                }
            }
            ?>
        </table>
        <center>
            <!-- <input type="submit" value="Submit" name="submit"> -->
            <button class="btn btn-primary" type="submit" name="marked" value="marked">Submit</button>
        </center>
    </form>
</div>

</div>
</div>
</div>
</header>
<?php include 'includes/footer.php' ?>
</body>

</html>