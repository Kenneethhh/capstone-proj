<?php
include 'db_conn.php';

if (isset($_POST['submit'])) {
    if ($_POST['submit'] == "new") {

        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $id = $_POST['id_prefix'] . $_POST['id'];
        $u_id = $id;
        $id = strtoupper($id);
        $password = $_POST['password'];
        $cPass = $_POST['confirm_password'];
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $year = $_POST['year'];
        $course = $_POST['course'];
        $section = $_POST['section'];
        // $semester = $_POST['semester'];

        $file_name = $_FILES["profile_pic"]["name"];
        $file_type = $_FILES["profile_pic"]["type"];
        $file_size = $_FILES["profile_pic"]["size"];
        $file_content = file_get_contents($_FILES["profile_pic"]["tmp_name"]);

        if (isset($_POST['subjects'])) {
            $selected_subjects = $_POST['subjects'];
        }

        $query = "SELECT * FROM users WHERE user_id='$id'";
        $result = mysqli_query($connection, $query);
        if ($result) {
            if (mysqli_num_rows($result) == '0') {
                $checkEmail = "SELECT * FROM users WHERE email='$email'";
                $emailResult = mysqli_query($connection, $checkEmail);
                if ($emailResult) {
                    if (mysqli_num_rows($emailResult) == '0') {

                        if ($password === $cPass) {
                            if (strpos($id, '01-') !== false) {
                                $insertQuery = "INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `email`, `phone`, `password`, `course`, `section`, `year`, `registered_as`)
                    VALUES ('$id', '$first_name', '$last_name', '$email', '$phone', '$hash', '$course', '$section', '$year', 'Student')";
                            } else if (strpos($id, '02-') !== false) {
                                $insertQuery = "INSERT INTO `users` (`user_id`, `first_name`,`last_name`,`email`, `phone` ,`password`, `registered_as`)
                    VALUES('$id', '$first_name', '$last_name', '$email', '$phone', '$hash', 'Teacher')";
                            } elseif (strpos($id, '03-') !== false) {
                                $insertQuery = "INSERT INTO `users` (`user_id`, `first_name`,`last_name`,`email`, `phone` ,`password`, `registered_as`)
                            VALUES('$id', '$first_name', '$last_name', '$email', '$phone', '$hash', 'Admin')";
                            } else {
                                echo '
                    <script>alert("Please Enter valid ID")</script>
                    <script>window.location.href = "../signup.php"</script>
                    ';
                                exit;
                            }
                            $result = mysqli_query($connection, $insertQuery);
                            if ($result) {
                                include('../phpqrcode/qrlib.php');
                                $filename = $id . '.png';
                                $filepath = '../img/' . $filename;
                                if (file_exists($filepath)) {
                                    unlink($filepath);
                                }
                                $path = '../img/';

                                QRcode::png($id, $path . '' . $id . '.png');

                                // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ PICTURE +++++++++++++++++++++++++++
                                if (isset($_FILES['profile_pic'])) {
                                    // Get the file info
                                    $file_name = mysqli_real_escape_string($connection, $file_name);
                                    $file_type = mysqli_real_escape_string($connection, $file_type);
                                    $file_size = mysqli_real_escape_string($connection, $file_size);
                                    $file_content = mysqli_real_escape_string($connection, $file_content);

                                    $insertQuery = "INSERT INTO `profile_picture` (`user_id`, `file_name`, `file_type`, `file_size`, `file_content`)
                VALUES('$u_id', '$file_name', '$file_type', '$file_size', '$file_content')";

                                    $result = mysqli_query($connection, $insertQuery);

                                    if (!$result) {
                                        // handle error
                                    }

                                    // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++ SUBJECTS +++++++++++++++++++++++++++++++++++

                                    if (isset($_POST['subjects'])) {
                                        foreach ($selected_subjects as $subject) {
                                            $insertQuery = "INSERT INTO `user_subject` (`user_id`, `subject`)
                                    VALUES('$id', '$subject')";
                                            $result = mysqli_query($connection, $insertQuery);
                                            if (!$result) {
                                                echo '
                                            <script>alert("We are facing some error while inserting user-subjects. Please Try again")</script>
                                            <script>window.location.href = "../signup.php"</script>
                                        ';
                                                // exit;
                                            }
                                        }
                                    }


                                    echo '
                <script>alert("Your Account has been created Successfully.")</script>
                <script>window.location.href = "../index.php"</script>
                ';
                                } else {
                                    echo '
                <script>alert("We are facing some error. Please Try again")</script>
                <script>window.location.href = "../signup.php"</script>
                ';
                                }
                            }  // INSERT SUCCESS
                        } else {
                            echo '
        <script>alert("Passwords do not match. Please try again")</script>
        <script>window.location.href = "../signup.php"</script>
        ';
                        }
                    } else {
                        echo '
        <script>alert("User with this email already exists.")</script>
        <script>window.location.href = "../signup.php"</script>
        ';
                    }
                } //emailresult true
            } else {
                echo '
            <script>alert("User with this ID already exists.")</script>
            <script>window.location.href = "../signup.php"</script>
            ';
            }
        } //result true



    } else {

        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $id = $_POST['id'];
        $u_id = $id;
        $id = strtoupper($id);
        $password = $_POST['password'];
        $cPass = $_POST['confirm_password'];
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $year = $_POST['year'];
        $course = $_POST['course'];
        $section = $_POST['section'];
        // $semester = $_POST['semester'];

        if ($_FILES["profile_pic"]["name"] != "") {
            $img_update = true;
            $file_name = $_FILES["profile_pic"]["name"];
            $file_type = $_FILES["profile_pic"]["type"];
            $file_size = $_FILES["profile_pic"]["size"];
            $file_content = file_get_contents($_FILES["profile_pic"]["tmp_name"]);
        } else {
            $img_update = false;
        }

        if ($password != "") {
            $pass_update = true;
        } else {
            $pass_update = false;
        }

        if (isset($_POST['subjects'])) {
            $selected_subjects = $_POST['subjects'];
        }

        if ($pass_update) {
            if ($password == $cPass) {
                $update_sql = "UPDATE users set password='" . $hash . "' where user_id='" . $id . "' ";
                $result = mysqli_query($connection, $update_sql);
            }
        }

        if ($img_update) {

            $file_name = mysqli_real_escape_string($connection, $file_name);
            $file_type = mysqli_real_escape_string($connection, $file_type);
            $file_size = mysqli_real_escape_string($connection, $file_size);
            $file_content = mysqli_real_escape_string($connection, $file_content);
            $update_sql = "UPDATE `profile_picture` set file_name = '" . $file_name . "', file_type = '" . $file_type . "', file_size = '" . $file_size . "', file_content = '" . $file_content . "' where user_id='" . $id . "' ";
            $result = mysqli_query($connection, $update_sql);
        }

        //UPDATE
        $update_sql = "UPDATE users set first_name='" . $first_name . "', last_name='" . $last_name . "', phone='" . $phone . "', course='" . $course . "', section='" . $section . "', year='" . $year . "' where user_id='" . $id . "' ";
        $result = mysqli_query($connection, $update_sql);
        if ($result) {

            $del_sql = "DELETE FROM `user_subject` where user_id='" . $id . "' ";
            $result = mysqli_query($connection, $del_sql);

            foreach ($selected_subjects as $subject) {
                $insertQuery = "INSERT INTO `user_subject` (`user_id`, `subject`)
            VALUES('$id', '$subject')";
                $result = mysqli_query($connection, $insertQuery);
                if (!$result) {
                    echo '
                    <script>alert("We are facing some error. Please Try again")</script>
                    <script>window.location.href = "../user_list.php"</script>
                    ';
                }
            }

            echo '
            <script>alert("Success Updating")</script>
            <script>window.location.href = "../user_list.php"</script>
            ';
        } else {
            echo '
            <script>alert("We are facing some error. Please Try again")</script>
            <script>window.location.href = "../user_list.php"</script>
            ';
        }
    }
}
