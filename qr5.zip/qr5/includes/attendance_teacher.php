<?php
$u_id = $_SESSION['user_id'];
$sql = "SELECT * FROM attendance LEFT JOIN users ON attendance.student_id = users.user_id WHERE attendance.student_id = '$u_id'";


$sql .= " group by student_id,date order by date DESC";
// echo $sql;


$sqlResult = mysqli_query($connection, $sql);

?>





<div class="table mt">
    <br>
    <table class="table table-bordered">
        <thead>
            <tr>
            <th>No.</th>
                <th>Date</th>
                <th>Time IN</th>
                <th>Time OUT</th>
            </tr>
        </thead>

        <?php

        if ($sqlResult) {
            if (mysqli_num_rows($sqlResult) == '0') {
                echo '<h1>No Result found</h1>';
            }
            $sno = 0;
            while ($attendance_row = mysqli_fetch_assoc($sqlResult)) {
                $date = $attendance_row['date'];
                $time = $attendance_row['time'];
                $log = $attendance_row['log'];
                $student_id = $attendance_row["student_id"];
                $sno++;

                $logs_sql = "SELECT student_id,date,max(time) as time_out, min(time) as time_in FROM `attendance` where student_id='".$student_id."' and date='".$date."' ";
                $log_result = mysqli_query($connection, $logs_sql);
                while ($log_row = mysqli_fetch_assoc($log_result)) {
                    $time_in =   date("h:i A",strtotime($log_row["time_in"]));

                    if($log_row["time_out"] == $log_row["time_in"]){
                        $time_out = "-";
                    }else{
                        $time_out = date("h:i A",strtotime($log_row["time_out"]));
                    }

                  
                    
                    ?>
                    <tr>
                        <td><?php echo $sno ?></td>
                        <td><?php echo $date ?></td>
                        <td><?php echo $time_in; ?></td>
                        <td><?php echo $time_out ?></td>
    
                    </tr>
                <?php
            }
        }
    }
        ?>


        <tbody>








        </tbody>
    </table>
</div>

</div>
</div>
</div>
</header>
<?php include 'includes/footer.php' ?>
</body>

</html>